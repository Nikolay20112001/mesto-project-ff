// @todo: Функция создания карточки
function createCard(cardTemplate, name, link, deleteCard) {
    const cardElement = cardTemplate.querySelector('.card').cloneNode(true);
    const cardImage = cardElement.querySelector('.card__image');
    cardImage.src = link;
    cardImage.alt = name;
    cardElement.querySelector(".card__title").textContent = name;
    cardElement.querySelector(".card__delete-button").addEventListener('click', function() {
        deleteCard(cardElement);
    });
    cardElement.querySelector(".card__like-button").addEventListener('click', like);
    return cardElement;
}

// @todo: Функция удаления карточки
function deleteCard(cardElement) {
    cardElement.remove();
}

function like(evt) {
    if (evt.target.classList.contains('card__like-button')) {
        evt.target.classList.toggle('card__like-button_is-active');
    }
}

export {createCard, deleteCard, like};