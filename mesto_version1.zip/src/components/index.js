import '../pages/index.css';
import initialCards from './cards.js';
import { createCard, deleteCard } from './card.js';
import { openModal, closeModal } from './modal.js';
// @todo: Темплейт карточки
const cardTemplate = document.querySelector("#card-template").content;
// @todo: DOM узлы
const places = document.querySelector('.places');
const placesContainer = places.querySelector('.places__list');
const addButton = document.querySelector(".profile__add-button");
const editButton = document.querySelector(".profile__edit-button");
const cardElement = cardTemplate.querySelector('.card').cloneNode(true);
const deleteButton = placesContainer.querySelector(".card__delete-button");

const popup1 = document.querySelector(".popup_type_new-card");
const popup2 = document.querySelector(".popup_type_edit");
const popup3 = document.querySelector(".popup_type_image");
const popupImage = document.querySelector(".popup__image");

const formNewPlace = document.forms["new-place"];
const placeNameInput = formNewPlace.elements["place-name"];
const linkInput = formNewPlace.elements.link;

const formEditProfile = document.forms["edit-profile"];
const nameInput = formEditProfile.elements.name;
const jobInput = formEditProfile.elements.description;

const profile = document.querySelector('.profile');
const profileInfo = profile.querySelector('.profile__info');
const profileName = profileInfo.querySelector('.profile__title');
const profileDescription = profileInfo.querySelector('.profile__description');


// @todo: Вывести карточки на страницу
initialCards.forEach(function (elements) {
    placesContainer.append(createCard(cardTemplate, elements.name, elements.link, deleteCard)); 
});

addButton.addEventListener('click', function() {
    openModal(popup1);
});

editButton.addEventListener('click', function() {
    openModal(popup2);
    nameInput.value = profileName.textContent;
    jobInput.value = profileDescription.textContent;
});

places.addEventListener('click', function(evt) {
    if (evt.target.classList.contains('card__image')) {
        openModal(popup3);
        popupImage.src = evt.target.src;
    }
});

function handleEditProfileSubmit(evt) {
    evt.preventDefault();
    profileName.textContent = nameInput.value;
    profileDescription.textContent = jobInput.value;
    closeModal(popup2);
}

function handleNewPlace(evt) {
    evt.preventDefault();
    placesContainer.prepend(createCard(cardTemplate, placeNameInput.value, linkInput.value, deleteCard));
    formNewPlace.reset();
    closeModal(popup1);
}

formEditProfile.addEventListener('submit', handleEditProfileSubmit);
formNewPlace.addEventListener('submit', handleNewPlace);
