import '../pages/index.css';
import initialCards from './cards.js';
import { createCard, deleteCard } from './card.js';
import { openModal, closeModal } from './modal.js';
// @todo: Темплейт карточки
const cardTemplate = document.querySelector("#card-template").content;
// @todo: DOM узлы
const places = document.querySelector('.places');
const placesContainer = places.querySelector('.places__list');
const addButton = document.querySelector(".profile__add-button");
const editButton = document.querySelector(".profile__edit-button");
const cardElement = cardTemplate.querySelector('.card').cloneNode(true);
const deleteButton = placesContainer.querySelector(".card__delete-button");

const popups = document.querySelectorAll('.popup');
const popupAddCard = document.querySelector(".popup_type_new-card");
const popupEditProfile = document.querySelector(".popup_type_edit");
const popupCardImage = document.querySelector(".popup_type_image");
const popupImage = popupCardImage.querySelector(".popup__image");
const popupTitle = popupCardImage.querySelector(".popup__caption");

const formNewPlace = document.forms["new-place"];
const placeNameInput = formNewPlace.elements["place-name"];
const linkInput = formNewPlace.elements.link;

const formEditProfile = document.forms["edit-profile"];
const nameInput = formEditProfile.elements.name;
const jobInput = formEditProfile.elements.description;

const profile = document.querySelector('.profile');
const profileInfo = profile.querySelector('.profile__info');
const profileName = profileInfo.querySelector('.profile__title');
const profileDescription = profileInfo.querySelector('.profile__description');


// @todo: Вывести карточки на страницу
initialCards.forEach(function (elements) {
    placesContainer.append(createCard(cardTemplate, elements.name, elements.link, deleteCard, handleOpenPhoto)); 
});

popups.forEach((popup) => {
    const closeButton = popup.querySelector(".popup__close")
    closeButton.addEventListener("click", () => {
       closeModal(popup);
    });
})

popups.forEach((popup) => {
    popup.addEventListener("mousedown", (evt) => {
        if (evt.target.classList.contains("popup")) {
            closeModal(popup);
        }
    });
}); 

addButton.addEventListener('click', function() {
    openModal(popupAddCard);
});

editButton.addEventListener('click', function() {
    openModal(popupEditProfile);
    nameInput.value = profileName.textContent;
    jobInput.value = profileDescription.textContent;
});

function handleEditProfileSubmit(evt) {
    evt.preventDefault();
    profileName.textContent = nameInput.value;
    profileDescription.textContent = jobInput.value;
    closeModal(popupEditProfile);
}

function handleNewPlace(evt) {
    evt.preventDefault();
    placesContainer.prepend(createCard(cardTemplate, placeNameInput.value, linkInput.value, deleteCard, handleOpenPhoto));
    formNewPlace.reset();
    closeModal(popupAddCard);
}

function handleOpenPhoto(name, link) {
    openModal(popupCardImage);
    popupImage.src = link;
    popupTitle.textContent = name;
}

formEditProfile.addEventListener('submit', handleEditProfileSubmit);
formNewPlace.addEventListener('submit', handleNewPlace);
